# painting-ants
Some ants painting not so random stuff
